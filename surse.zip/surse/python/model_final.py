import pandas as pd
from sklearn.model_selection import train_test_split
from datasets import Dataset, load_metric
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments, AdamW, \
    EarlyStoppingCallback
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import numpy as np

data_path = 'mtsamples3.csv'
df = pd.read_csv(data_path)

specialties_to_exclude = [
    "Bariatrics", "Speech - Language", "SOAP / Chart / Progress Notes",
    "Sleep Medicine", "Physical Medicine - Rehab", "Pain Management",
    "Office Notes", "Letters", "IME-QME-Work Comp etc.",
    "Emergency Room Reports", "Discharge Summary",
    "Diets and Nutritions", "Consult - History and Phy.", "Autopsy",
    "Podiatry", "Dermatology", "Cosmetic / Plastic Surgery", "Dentistry", "Endocrinology", "Chiropractic",
    "Rheumatology",
    "Allergy / Immunology", "Hospice - Palliative Care",
    "Lab Medicine - Pathology"
]
df = df[~df['medical_specialty'].str.strip().isin(specialties_to_exclude)]

df['medical_specialty'] = df['medical_specialty'].apply(lambda x: x.strip())

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()


def preprocess_text(text):
    if isinstance(text, str):
        tokens = word_tokenize(text.lower())
        tokens = [lemmatizer.lemmatize(word) for word in tokens if word.isalpha() and word not in stop_words]
        return ' '.join(tokens)
    else:
        return ""


df['transcription'] = df['keywords'].fillna('') + " " + df['transcription']
df['cleaned_transcription'] = df['transcription'].apply(preprocess_text)

label_to_id = {label: i for i, label in enumerate(df['medical_specialty'].unique())}

df['label'] = df['medical_specialty'].map(label_to_id)

train_df, test_df = train_test_split(df, test_size=0.2, stratify=df['medical_specialty'], random_state=42)
train_df, validation_df = train_test_split(train_df, test_size=0.25, stratify=train_df['medical_specialty'],
                                           random_state=42)

# Conversie Pandas DataFrame in Huggingface Dataset
train_dataset = Dataset.from_pandas(train_df)
test_dataset = Dataset.from_pandas(test_df)
validation_dataset = Dataset.from_pandas(validation_df)

#  Tokenizarea textului
model_name = "emilyalsentzer/Bio_ClinicalBERT"
tokenizer = BertTokenizer.from_pretrained(model_name)
max_length = 512  # Dim maxima


def tokenize_function(examples):
    return tokenizer(examples['cleaned_transcription'], padding="max_length", truncation=True, max_length=max_length)


train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)
validation_dataset = validation_dataset.map(tokenize_function, batched=True)


# Adaugare etichetelor in seturile de date
def format_labels(examples):
    examples['labels'] = examples['label']
    return examples


train_dataset = train_dataset.map(format_labels, batched=True)
test_dataset = test_dataset.map(format_labels, batched=True)
validation_dataset = validation_dataset.map(format_labels, batched=True)

model = BertForSequenceClassification.from_pretrained(model_name, num_labels=len(label_to_id)).to('cuda')

# arg de antrenament
training_args = TrainingArguments(
    output_dir='./results5m',
    evaluation_strategy="epoch",
    save_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    report_to="none",
    per_device_eval_batch_size=16,
    num_train_epochs=7,
    load_best_model_at_end=True,
    weight_decay=0.01,
)

early_stopping = EarlyStoppingCallback()

accuracy_metric = load_metric("accuracy")
f1_metric = load_metric("f1")
precision_metric = load_metric("precision")
recall_metric = load_metric("recall")


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)

    accuracy = accuracy_metric.compute(predictions=predictions, references=labels)
    f1 = f1_metric.compute(predictions=predictions, references=labels, average="macro")
    precision = precision_metric.compute(predictions=predictions, references=labels, average="macro")
    recall = recall_metric.compute(predictions=predictions, references=labels, average="macro")

    return {
        'accuracy': accuracy['accuracy'],
        'f1': f1['f1'],
        'precision': precision['precision'],
        'recall': recall['recall']
    }


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=validation_dataset,
    compute_metrics=compute_metrics,
    callbacks=[early_stopping]
)

trainer.train()

eval_results = trainer.evaluate(eval_dataset=test_dataset)
print(eval_results)
print(f"Acuratețea modelului: {eval_results['eval_accuracy']}")

# {'eval_loss': 0.378438800573349, 'eval_accuracy': 0.9001349527665317, 'eval_f1': 0.8875271652086928, 'eval_precision': 0.9103845332949447, 'eval_recall': 0.8780689112953882, 'eval_runtime': 7.4463, 'eval_samples_per_second': 99.513, 'eval_steps_per_second': 6.312, 'epoch': 5.0}
# Acuratețea modelului: 0.9001349527665317

model.save_pretrained('./model_iustifil')
tokenizer.save_pretrained('./model_iustifil')

# classification_report
#
#                             precision    recall  f1-score   support
#
# Cardiovascular / Pulmonary       0.84      0.89      0.86        74
#       ENT - Otolaryngology       0.95      0.90      0.92        20
#           Gastroenterology       0.90      0.80      0.85        46
#           General Medicine       0.92      0.67      0.78        52
#      Hematology - Oncology       0.77      0.94      0.85        18
#                 Nephrology       1.00      0.81      0.90        16
#                  Neurology       0.82      0.89      0.85        45
#               Neurosurgery       1.00      0.95      0.97        19
#    Obstetrics / Gynecology       1.00      0.78      0.88        32
#              Ophthalmology       0.94      1.00      0.97        16
#                 Orthopedic       0.88      0.96      0.92        71
#      Pediatrics - Neonatal       1.00      0.64      0.78        14
#    Psychiatry / Psychology       0.75      0.90      0.82        10
#                  Radiology       0.95      0.95      0.95        55
#                    Surgery       0.91      0.96      0.93       221
#                    Urology       0.94      1.00      0.97        32
#
#                   accuracy                           0.90       741
#                  macro avg       0.91      0.88      0.89       741
#               weighted avg       0.90      0.90      0.90       741


# Am eliminat categoriile care nu reprezentau niste specializari:

# Compara cu model fara curatare
# fara keywords
# fara eliminare categorii cu numar mic de exemple

# Oversampling pentru categorii mici duce la a avea aceleasi date si in train set si in validation set si in test set
# si face predictii gresite in real life examples --> ar trebui generate date noi
# Are acuratete mare 0.94 dar nu se descurca in cadrul aplicatiei


# early stopping

# validation set
