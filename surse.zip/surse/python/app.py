from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import BertTokenizer, BertForSequenceClassification
import torch
import json

app = FastAPI()


class TextRequest(BaseModel):
    text: str


model_path = './model_iustifil'
tokenizer = BertTokenizer.from_pretrained(model_path)
model = BertForSequenceClassification.from_pretrained(model_path)

with open('label_to_id.json', 'r') as f:
    label_to_id = json.load(f)
id_to_label = {v: k for k, v in label_to_id.items()}


def preprocess_text(text):
    return text.lower()


@app.post("/predict")
def predict(request: TextRequest):
    try:
        text = preprocess_text(request.text)
        inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
        with torch.no_grad():
            outputs = model(**inputs)
        logits = outputs.logits
        predicted_class_id = logits.argmax().item()
        predicted_class_label = id_to_label[predicted_class_id]
        print(request.text)
        print(predicted_class_label)
        return {"predicted_class_label": predicted_class_label}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
