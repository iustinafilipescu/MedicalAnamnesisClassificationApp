package com.nlp.healthcare.controllers;

import com.nlp.healthcare.entities.Patient;
import com.nlp.healthcare.repositories.PatientRepository;
import com.nlp.healthcare.services.PatientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class PatientControllerTest {

    private MockMvc mockMvc;
    @Mock
    private PatientService patientService;
    @Mock
    private WebClient.Builder webClientBuilder;
    @Mock
    private PatientRepository patientRepository;
    @InjectMocks
    private PatientController patientController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(patientController).build();
    }

    @Test
    void testAddPatient() throws Exception {
        Patient patient = new Patient();
        patient.setCnp("1");
        patient.setLastName("Doe");

        when(patientService.addPatient(any(Patient.class))).thenReturn(patient);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/patients/post")
                        .content("{\"cnp\":\"1\",\"lastName\":\"John Doe\"}")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cnp").value("1"))
                .andExpect(jsonPath("$.lastName").value("Doe"));

        verify(patientService, times(1)).addPatient(any(Patient.class));
        verifyNoMoreInteractions(patientService);
    }

    @Test
    void testGetAllPatients() throws Exception {
        Patient patient1 = new Patient();
        patient1.setCnp("1");
        patient1.setLastName("Doe");

        Patient patient2 = new Patient();
        patient2.setCnp("2");
        patient2.setLastName("Doe");

        List<Patient> patients = Arrays.asList(patient1, patient2);

        when(patientService.getAllPatients()).thenReturn(patients);

        mockMvc.perform(get("/api/patients"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].cnp").value("1"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"))
                .andExpect(jsonPath("$[1].cnp").value("2"))
                .andExpect(jsonPath("$[1].lastName").value("Doe"));

        verify(patientService, times(1)).getAllPatients();
        verifyNoMoreInteractions(patientService);
    }

    @Test
    void testGetPatient() throws Exception {
        Patient patient = new Patient();
        patient.setCnp("1");
        patient.setLastName("Doe");

        when(patientService.getPatientById("1")).thenReturn(patient);

        mockMvc.perform(get("/api/patients/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cnp").value("1"))
                .andExpect(jsonPath("$.lastName").value("Doe"));

        verify(patientService, times(1)).getPatientById("1");
        verifyNoMoreInteractions(patientService);
    }

    @Test
    void testUpdateSpeciality() throws Exception {
        Patient existingPatient = new Patient();
        existingPatient.setCnp("1");
        existingPatient.setAnamnesis("Medical history content");

        when(patientService.getPatientById("1")).thenReturn(existingPatient);
        when(patientRepository.save(any(Patient.class))).thenReturn(existingPatient);

        WebClient webClient = mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.baseUrl(anyString())).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("{\"predicted_class_label\":\"Speciality\"}"));

        mockMvc.perform(put("/api/patients/1/update-speciality"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cnp").value("1"))
                .andExpect(jsonPath("$.speciality").value("Speciality"));

        verify(patientService, times(1)).getPatientById("1");
        verify(patientRepository, times(1)).save(any(Patient.class));
        verifyNoMoreInteractions(patientService, patientRepository);
    }


}
