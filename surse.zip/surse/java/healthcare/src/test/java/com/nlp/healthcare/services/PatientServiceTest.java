package com.nlp.healthcare.services;

import com.nlp.healthcare.entities.Patient;
import com.nlp.healthcare.repositories.PatientRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PatientServiceTest {

    @Mock
    private PatientRepository patientRepository;

    @InjectMocks
    private PatientService patientService;

    @Test
    void testAddPatient() {
        Patient patient = new Patient();
        patient.setCnp("123456789");

        when(patientRepository.findById("123456789")).thenReturn(Optional.empty());
        when(patientRepository.save(patient)).thenReturn(patient);

        Patient addedPatient = patientService.addPatient(patient);

        assertEquals(patient, addedPatient);
        verify(patientRepository, times(1)).findById("123456789");
        verify(patientRepository, times(1)).save(patient);
    }

    @Test
    void testAddPatientWithExistingId() {
        Patient patient = new Patient();
        patient.setCnp("existingId");

        when(patientRepository.findById("existingId")).thenReturn(Optional.of(patient));

        assertThrows(RuntimeException.class, () -> patientService.addPatient(patient));
        verify(patientRepository, times(1)).findById("existingId");
        verify(patientRepository, never()).save(any());
    }

    @Test
    void testGetAllPatients() {
        Patient patient1 = new Patient();
        Patient patient2 = new Patient();
        List<Patient> patientList = Arrays.asList(patient1, patient2);

        when(patientRepository.findAll()).thenReturn(patientList);

        List<Patient> result = patientService.getAllPatients();

        assertEquals(patientList, result);
        verify(patientRepository, times(1)).findAll();
    }

    @Test
    void testGetPatientById() {
        Patient patient = new Patient();
        patient.setCnp("123456789");

        when(patientRepository.getReferenceById("123456789")).thenReturn(patient);

        Patient result = patientService.getPatientById("123456789");

        assertEquals(patient, result);
        verify(patientRepository, times(1)).getReferenceById("123456789");
    }
}
