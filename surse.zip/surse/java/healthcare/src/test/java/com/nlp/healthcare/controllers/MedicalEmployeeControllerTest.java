package com.nlp.healthcare.controllers;

import com.nlp.healthcare.entities.MedicalEmployee;
import com.nlp.healthcare.services.MedicalEmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class MedicalEmployeeControllerTest {

    @Mock
    private MedicalEmployeeService medicalEmployeeService;

    @InjectMocks
    private MedicalEmployeeController medicalEmployeeController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateMedicalEmployee() {
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        when(medicalEmployeeService.createMedicalEmployee(any(MedicalEmployee.class))).thenReturn(medicalEmployee);

        MedicalEmployee result = medicalEmployeeController.createMedicalEmployee(medicalEmployee);

        assertEquals(medicalEmployee, result);
        verify(medicalEmployeeService, times(1)).createMedicalEmployee(any(MedicalEmployee.class));
    }

    @Test
    void testAuthenticateUser_Success() {
        when(medicalEmployeeService.authenticateUser(anyString(), anyString())).thenReturn(true);

        ResponseEntity<String> result = medicalEmployeeController.authenticateUser("username", "password");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals("User authenticated successfully", result.getBody());
        verify(medicalEmployeeService, times(1)).authenticateUser(anyString(), anyString());
    }

    @Test
    void testAuthenticateUser_Failure() {
        when(medicalEmployeeService.authenticateUser(anyString(), anyString())).thenReturn(false);

        ResponseEntity<String> result = medicalEmployeeController.authenticateUser("username", "password");

        assertEquals(HttpStatus.UNAUTHORIZED, result.getStatusCode());
        assertEquals("Authentication failed", result.getBody());
        verify(medicalEmployeeService, times(1)).authenticateUser(anyString(), anyString());
    }

    @Test
    void testGetAllMedicalEmployees() {
        List<MedicalEmployee> medicalEmployees = Arrays.asList(new MedicalEmployee(), new MedicalEmployee());
        when(medicalEmployeeService.getAllEmployees()).thenReturn(medicalEmployees);

        List<MedicalEmployee> result = medicalEmployeeController.getAllMedicalEmployees();

        assertEquals(medicalEmployees.size(), result.size());
        assertTrue(result.containsAll(medicalEmployees));
        verify(medicalEmployeeService, times(1)).getAllEmployees();
    }
}
