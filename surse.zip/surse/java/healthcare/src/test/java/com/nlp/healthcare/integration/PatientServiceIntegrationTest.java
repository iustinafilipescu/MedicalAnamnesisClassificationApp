package com.nlp.healthcare.integration;

import com.nlp.healthcare.entities.Patient;
import com.nlp.healthcare.repositories.PatientRepository;
import com.nlp.healthcare.services.PatientService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class PatientServiceIntegrationTest {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PatientService patientService;

    @Test
    void testAddPatient() {
        // Given
        Patient patient = new Patient();
        patient.setCnp("1234567890123");
        patient.setLastName("Doe");

        // When
        Patient addedPatient = patientService.addPatient(patient);

        // Then
        assertEquals(patient, addedPatient);
    }

    @Test
    void testAddPatientWithExistingId() {
        // Given
        Patient existingPatient = new Patient();
        existingPatient.setCnp("1234567890123");
        existingPatient.setLastName("Existing Patient");
        patientRepository.save(existingPatient);

        Patient newPatient = new Patient();
        newPatient.setCnp("1234567890123");
        newPatient.setLastName("Doe");

        // When/Then
        assertThrows(RuntimeException.class, () -> patientService.addPatient(newPatient));
    }


    @Test
    void testGetPatientById() {
        // Given
        Patient patient = new Patient();
        patient.setCnp("1234567890123");
        patient.setLastName("Doe");
        patientRepository.save(patient);

        // When
        Patient retrievedPatient = patientService.getPatientById("1234567890123");

        // Then
        assertEquals(patient, retrievedPatient);
    }
}
