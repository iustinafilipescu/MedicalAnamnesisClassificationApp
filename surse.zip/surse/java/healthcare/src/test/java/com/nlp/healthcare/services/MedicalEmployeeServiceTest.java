package com.nlp.healthcare.services;

import com.nlp.healthcare.entities.MedicalEmployee;
import com.nlp.healthcare.repositories.MedicalEmployeeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MedicalEmployeeServiceTest {

    @Mock
    private MedicalEmployeeRepository medicalEmployeeRepository;

    @InjectMocks
    private MedicalEmployeeService medicalEmployeeService;

    @Test
    void testCreateMedicalEmployee() {
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        medicalEmployee.setUsername("testUser");
        medicalEmployee.setPassword("testPassword");

        when(medicalEmployeeRepository.findByUsername("testUser")).thenReturn(Optional.empty());
        when(medicalEmployeeRepository.save(medicalEmployee)).thenReturn(medicalEmployee);

        MedicalEmployee createdEmployee = medicalEmployeeService.createMedicalEmployee(medicalEmployee);

        assertEquals(medicalEmployee, createdEmployee);
        verify(medicalEmployeeRepository, times(1)).findByUsername("testUser");
        verify(medicalEmployeeRepository, times(1)).save(medicalEmployee);
    }

    @Test
    void testCreateMedicalEmployeeWithExistingUsername() {
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        medicalEmployee.setUsername("existingUser");
        medicalEmployee.setPassword("testPassword");

        when(medicalEmployeeRepository.findByUsername("existingUser")).thenReturn(Optional.of(medicalEmployee));

        assertThrows(RuntimeException.class, () -> medicalEmployeeService.createMedicalEmployee(medicalEmployee));
        verify(medicalEmployeeRepository, times(1)).findByUsername("existingUser");
        verify(medicalEmployeeRepository, never()).save(any());
    }

    @Test
    void testAuthenticateUser() {
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        medicalEmployee.setUsername("testUser");
        medicalEmployee.setPassword("testPassword");

        when(medicalEmployeeRepository.findByUsername("testUser")).thenReturn(Optional.of(medicalEmployee));

        boolean isAuthenticated = medicalEmployeeService.authenticateUser("testUser", "testPassword");

        assertTrue(isAuthenticated);
        verify(medicalEmployeeRepository, times(1)).findByUsername("testUser");
    }

    @Test
    void testAuthenticateUserWithInvalidPassword() {
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        medicalEmployee.setUsername("testUser");
        medicalEmployee.setPassword("testPassword");

        when(medicalEmployeeRepository.findByUsername("testUser")).thenReturn(Optional.of(medicalEmployee));

        boolean isAuthenticated = medicalEmployeeService.authenticateUser("testUser", "wrongPassword");

        assertFalse(isAuthenticated);
        verify(medicalEmployeeRepository, times(1)).findByUsername("testUser");
    }

    @Test
    void testAuthenticateUserWithNonexistentUser() {
        when(medicalEmployeeRepository.findByUsername("nonexistentUser")).thenReturn(Optional.empty());

        boolean isAuthenticated = medicalEmployeeService.authenticateUser("nonexistentUser", "password");

        assertFalse(isAuthenticated);
        verify(medicalEmployeeRepository, times(1)).findByUsername("nonexistentUser");
    }

    @Test
    void testGetAllEmployees() {
        MedicalEmployee employee1 = new MedicalEmployee();
        MedicalEmployee employee2 = new MedicalEmployee();
        List<MedicalEmployee> employeeList = Arrays.asList(employee1, employee2);

        when(medicalEmployeeRepository.findAll()).thenReturn(employeeList);

        List<MedicalEmployee> result = medicalEmployeeService.getAllEmployees();

        assertEquals(employeeList, result);
        verify(medicalEmployeeRepository, times(1)).findAll();
    }
}
