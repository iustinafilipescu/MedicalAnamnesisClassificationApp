package com.nlp.healthcare.integration;

import com.nlp.healthcare.entities.MedicalEmployee;
import com.nlp.healthcare.repositories.MedicalEmployeeRepository;
import com.nlp.healthcare.services.MedicalEmployeeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("test")
public class MedicalEmployeeServiceIntegrationTest {

    @Autowired
    private MedicalEmployeeService medicalEmployeeService;

    @Autowired
    private MedicalEmployeeRepository medicalEmployeeRepository;

    @Test
    public void testCreateMedicalEmployee() {
        // Given
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        String random = UUID.randomUUID().toString();
        medicalEmployee.setUsername("testUser" + random);
        medicalEmployee.setPassword("testPassword");

        // When
        MedicalEmployee createdEmployee = medicalEmployeeService.createMedicalEmployee(medicalEmployee);

        // Then
        assertNotNull(createdEmployee.getUsername());
        assertEquals("testUser" + random, createdEmployee.getUsername());
    }

    @Test
    public void testAuthenticateUser() {
        // Given
        MedicalEmployee medicalEmployee = new MedicalEmployee();
        medicalEmployee.setUsername("testUser");
        medicalEmployee.setPassword("testPassword");
        medicalEmployeeRepository.save(medicalEmployee);

        // When
        boolean isAuthenticated = medicalEmployeeService.authenticateUser("testUser", "testPassword");

        // Then
        assertTrue(isAuthenticated);
    }

    @Test
    public void testGetAllEmployees() {
        // When
        Iterable<MedicalEmployee> employees = medicalEmployeeService.getAllEmployees();

        // Then
        assertNotNull(employees);
    }
}
