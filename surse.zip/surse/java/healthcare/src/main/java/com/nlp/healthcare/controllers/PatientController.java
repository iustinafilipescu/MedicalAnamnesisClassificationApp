package com.nlp.healthcare.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nlp.healthcare.entities.Patient;
import com.nlp.healthcare.repositories.PatientRepository;
import com.nlp.healthcare.services.PatientService;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private static final Logger logger = LoggerFactory.getLogger(PatientController.class);
    @Autowired
    private PatientService patientService;
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private WebClient.Builder webClientBuilder;

    @PostMapping("/post")
    public Patient addPatient(@RequestBody Patient patient) {
        return patientService.addPatient(patient);
    }

    @GetMapping
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    @GetMapping("/{patientId}")
    public Patient getPatient(@PathVariable String patientId) {
        return patientService.getPatientById(patientId);
    }

    @PutMapping("/{patientId}/update-speciality")
    public Patient updateSpeciality(@PathVariable String patientId) {
        Patient existingPatient = patientService.getPatientById(patientId);

        if (existingPatient != null) {
            String anamnesis = existingPatient.getAnamnesis();

            WebClient webClient = webClientBuilder.baseUrl("http://localhost:8000").build();
            try {
                String rawResponse = webClient.post()
                        .uri("/predict")
                        .bodyValue(new PredictionRequest(anamnesis))
                        .retrieve()
                        .bodyToMono(String.class)
                        .block();


                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(rawResponse);
                String predictedSpeciality = jsonNode.get("predicted_class_label").asText();


                existingPatient.setSpeciality(predictedSpeciality);

                return patientRepository.save(existingPatient);
            } catch (WebClientResponseException e) {
                logger.error("Error from Python server: " + e.getResponseBodyAsString(), e);
            } catch (Exception e) {
                logger.error("Error while processing response: ", e);
            }
        }
        return null;
    }

    @Getter
    @Setter
    private static class PredictionRequest {
        private String text;

        public PredictionRequest(String text) {
            this.text = text;
        }
    }
}
