package com.nlp.healthcare.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@Entity
public class Patient {

    @Id
    private String cnp; //cnp
    private String firstName;
    private String lastName;
    private String age;
    private String gender;
    private String anamnesis;
    private String weight;
    private String height;
    private String speciality;
    private String addedBy;

    @Override
    public String toString() {
        return "Patient with " +
                "id='" + cnp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Patient patient = (Patient) o;
        return Objects.equals(getCnp(), patient.getCnp()) &&
                Objects.equals(getLastName(), patient.getLastName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCnp(), getLastName());
    }
}
