package com.nlp.healthcare.controllers;

import com.nlp.healthcare.entities.MedicalEmployee;
import com.nlp.healthcare.services.MedicalEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/medicalemployees")
public class MedicalEmployeeController {

    @Autowired
    private MedicalEmployeeService MedicalEmployeeService;

    @PostMapping(path = "/post")
    public MedicalEmployee createMedicalEmployee(@RequestBody MedicalEmployee MedicalEmployee) {
        return MedicalEmployeeService.createMedicalEmployee(MedicalEmployee);
    }

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticateUser(@RequestParam String username, @RequestParam String password) {
        boolean isAuthenticated = MedicalEmployeeService.authenticateUser(username, password);

        if (isAuthenticated) {
            return new ResponseEntity<>("User authenticated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Authentication failed", HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping
    public List<MedicalEmployee> getAllMedicalEmployees() {
        return MedicalEmployeeService.getAllEmployees();
    }

}