package com.nlp.healthcare.aspect;

import com.nlp.healthcare.entities.Patient;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Aspect
@Component
public class LoggingAspect {

    @Before("execution(* com.nlp.healthcare.services.MedicalEmployeeService.*(..))" +
            " || execution(* com.nlp.healthcare.services.PatientService.*(..))")
    public void logMethodEntry(JoinPoint joinPoint) {
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();

        System.out.println("Entering " + className + "." + methodName + " with arguments: " + Arrays.toString(args));
    }

    @AfterReturning(pointcut = " execution(* com.nlp.healthcare.services.PatientService.*(..))", returning = "result")
    public void logMethodExit(JoinPoint joinPoint, List<Patient> result) {
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();

        System.out.println("Exiting " + className + "." + methodName + " with result: " + result.toString());
    }
}