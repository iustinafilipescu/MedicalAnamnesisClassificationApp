package com.nlp.healthcare.services;

import com.nlp.healthcare.entities.Patient;
import com.nlp.healthcare.repositories.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public Patient addPatient(Patient patient) {
        if (patientRepository.findById(patient.getCnp()).isPresent()) {
            throw new RuntimeException(String.format("Patient with id <%s> already exists", patient.getCnp()));
        }
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(String patientId) {
        return patientRepository.getReferenceById(patientId);
    }


}