package com.nlp.healthcare.services;

import com.nlp.healthcare.entities.MedicalEmployee;
import com.nlp.healthcare.repositories.MedicalEmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicalEmployeeService {

    @Autowired
    private MedicalEmployeeRepository medicalEmployeeRepository;

    public MedicalEmployee createMedicalEmployee(MedicalEmployee medicalEmployee) {
        if (medicalEmployeeRepository.findByUsername(medicalEmployee.getUsername()).isPresent()) {
            throw new RuntimeException(String.format("Medical Employee with username <%s> already exists", medicalEmployee.getUsername()));
        }
        return medicalEmployeeRepository.save(medicalEmployee);
    }

    public boolean authenticateUser(String username, String password) {
        Optional<MedicalEmployee> optionalMedicalEmployee = medicalEmployeeRepository.findByUsername(username);

        if (optionalMedicalEmployee.isPresent()) {
            MedicalEmployee medicalEmployee = optionalMedicalEmployee.get();
            return medicalEmployee.getPassword().equals(password);
        } else {
            return false;
        }
    }

    public List<MedicalEmployee> getAllEmployees() {
        return medicalEmployeeRepository.findAll();
    }

}