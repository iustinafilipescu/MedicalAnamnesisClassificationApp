package com.nlp.healthcare.repositories;

import com.nlp.healthcare.entities.MedicalEmployee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MedicalEmployeeRepository extends JpaRepository<MedicalEmployee, String> {
    Optional<MedicalEmployee> findByUsername(String username);

}
