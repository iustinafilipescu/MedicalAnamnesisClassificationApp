import React, {useState} from 'react';
import {BrowserRouter as Router, Navigate, Outlet, Route, Routes} from 'react-router-dom';
import './App.css';
import LoginPage from './LoginPage';
import Menu from './Menu';
import RegisterPatientPage from './RegisterPatientPage';
import RegisteredPatientsPage from './RegisteredPatientsPage';
import RegisterMedicalEmployeePage from './RegisterMedicalEmployeePage';
import RegisteredMedicalEmployeesPage from "./RegisteredMedicalEmployeesPage";

function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);
    const [username, setUsername] = useState('');

    const MainPage = () => {
        return (
            <div className="main-container">
                <Menu isAuthenticated={isAuthenticated} isAdmin={isAdmin} username={username}/>
                <Outlet/>
            </div>
        );
    };

    const handleLogin = (username, admin) => {
        setIsAuthenticated(true);
        setIsAdmin(admin);
        setUsername(username);
    };

    return (
        <Router>
            <Routes>
                <Route
                    path="/main/*"
                    element={
                        isAuthenticated ? (
                            <MainPage/>
                        ) : (
                            <Navigate to="/login" replace/>
                        )
                    }
                />
                <Route path="login" element={<LoginPage handleLogin={handleLogin}/>}/>
                <Route path="/register-patient" element={<RegisterPatientPage username={username}/>}/>
                <Route path="/registered-patients" element={<RegisteredPatientsPage isAdmin={isAdmin}/>}/>
                <Route path="/register-medical-employee" element={<RegisterMedicalEmployeePage username={username}/>}/>
                <Route path="/registered-medical-employees" element={<RegisteredMedicalEmployeesPage/>}/>

            </Routes>
        </Router>
    );
}

export default App;
