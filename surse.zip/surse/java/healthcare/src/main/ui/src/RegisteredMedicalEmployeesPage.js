import React, {useEffect, useState} from 'react';
import './RegisteredMedicalEmployeesPage.css';
import {useNavigate} from 'react-router-dom';

const RegisteredMedicalEmployeesPage = () => {
    const [medicalEmployees, setMedicalEmployees] = useState([]);
    const navigate = useNavigate();

    const fetchMedicalEmployees = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/medicalemployees');
            if (response.ok) {
                const data = await response.json();
                setMedicalEmployees(data);
            } else {
                console.error('Failed to fetch medical employees.');
            }
        } catch (error) {
            console.error('Error during fetch:', error);
        }
    };

    useEffect(() => {
        fetchMedicalEmployees();
    }, []);

    return (
        <div className="registered-employees-container">
            <div className="title-box">
                <h2 className="title">Registered Medical Employees</h2>
            </div>
            <table className="employees-table">
                <thead>
                <tr>
                    <th>Username</th>
                    <th>Name</th>
                </tr>
                </thead>
                <tbody>
                {medicalEmployees.map((employee) => (
                    <tr key={employee.id}>
                        <td>{employee.username}</td>
                        <td>{employee.name}</td>
                    </tr>
                ))}
                </tbody>
            </table>
            <button className="back-to-menu-button" onClick={() => navigate('/main')}>
                Back to Menu
            </button>
        </div>
    );
};

export default RegisteredMedicalEmployeesPage;
