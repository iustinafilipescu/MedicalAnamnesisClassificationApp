import React, {useState} from 'react';
import './RegisterPatientPage.css';
import {useNavigate} from "react-router-dom";

const RegisterPatientPage = ({username}) => {
    const navigate = useNavigate();
    const [patientData, setPatientData] = useState({
        firstName: '',
        lastName: '',
        cnp: '',
        age: '',
        gender: 'male',
        weight: '',
        height: '',
        anamnesis: '',
        addedBy: username
    });

    const handleChange = (e) => {
        const {name, value} = e.target;
        setPatientData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const isObjectEmpty = (obj) => {
        for (let key in obj) {
            if (obj[key] === '') {
                return true;
            }
        }
        return false;
    };


    const handleSubmit = async (e) => {

        e.preventDefault()
        if (isObjectEmpty(patientData) === true) {
            alert('Cannot leave empty fields.');
            return;
        }

        try {
            const response = await fetch('http://localhost:8080/api/patients/post', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(patientData),
            });

            if (response.ok) {
                console.log('Patient registered successfully');
                navigate('/main');
            } else {
                console.error('Failed to register patient');
            }

        } catch (error) {
            console.error('Error during registration:', error);
        }
    };

    return (
        <div className="register-patient-container">
            <div className="register-patient-form-container">
                <h2 className="register-patient-title">Register a Patient</h2>
                <form onSubmit={handleSubmit} className="register-patient-form">
                    <label className="full-width">
                        Last Name:
                        <input className="full-width" type="text" name="lastName" value={patientData.lastName}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        First Name:
                        <input className="full-width" type="text" name="firstName" value={patientData.firstName}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        CNP:
                        <input className="full-width" type="text" name="cnp" value={patientData.cnp}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        Age:
                        <input className="full-width" type="text" name="age" value={patientData.age}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        Gender:
                        <select className="full-width" name="gender" value={patientData.gender}
                                onChange={handleChange}>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select> </label>
                    <label className="full-width">
                        Weight:
                        <input className="full-width" type="text" name="weight" value={patientData.weight}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        Height:
                        <input className="full-width" type="text" name="height" value={patientData.height}
                               onChange={handleChange}/>
                    </label>
                    <label className="full-width">
                        Anamnesis:
                        <textarea className="full-width" name="anamnesis" value={patientData.anamnesis}
                                  onChange={handleChange}/>
                    </label>
                    <button type="submit" className="register-patient-submit-button">
                        Register
                    </button>
                </form>
            </div>
            <button className="back-to-menu-button" onClick={() => navigate('/main')}>Back to Menu</button>

        </div>
    );
};

export default RegisterPatientPage;
