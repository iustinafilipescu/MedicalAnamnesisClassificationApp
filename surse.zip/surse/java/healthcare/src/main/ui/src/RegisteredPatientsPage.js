import React, {useEffect, useState} from 'react';
import './RegisteredPatientsPage.css';
import {useNavigate} from 'react-router-dom';

const RegisteredPatientsPage = ({isAdmin}) => {
    const [patients, setPatients] = useState([]);
    const navigate = useNavigate();

    const fetchPatients = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/patients');
            if (response.ok) {
                const data = await response.json();
                setPatients(data);
            } else {
                console.error('Failed to fetch patients.');
            }
        } catch (error) {
            console.error('Error during fetch:', error);
        }
    };

    useEffect(() => {
        fetchPatients();
    }, []);

    const handlePredict = async (patientId) => {
        try {
            const response = await fetch(`http://localhost:8080/api/patients/${patientId}/update-speciality`, {
                method: 'PUT',
            });

            if (response.ok) {
                console.log(`Prediction successful for patient with ID ${patientId}`);
                fetchPatients();
            } else {
                console.error(`Failed to predict for patient with ID ${patientId}`);
            }
        } catch (error) {
            console.error('Error during prediction:', error);
        }
    };

    return (
        <div className="registered-patients-container">
            <div className="title-box">
                <h2 className="title">Registered Patients</h2>
            </div>
            <table className="patients-table">
                <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>CNP</th>
                    <th>Age</th>
                    <th>Weight</th>
                    <th>Height</th>
                    <th>Gender</th>
                    <th>Anamnesis</th>
                    <th>Added By</th>
                    <th>Speciality</th>
                    <th>Predict</th>
                </tr>
                </thead>
                <tbody>
                {patients.map((patient) => (
                    <tr key={patient.id}>
                        <td>{patient.firstName}</td>
                        <td>{patient.lastName}</td>
                        <td>{patient.cnp}</td>
                        <td>{patient.age}</td>
                        <td>{patient.weight}</td>
                        <td>{patient.height}</td>
                        <td>{patient.gender}</td>
                        <td>{patient.anamnesis}</td>
                        <td>{patient.addedBy}</td>
                        <td>{patient.speciality}</td>
                        <td>
                            <button disabled={patient.speciality !== null} className="predict-button"
                                    onClick={() => handlePredict(patient.cnp)}>
                                Predict
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <button className="back-to-menu-button" onClick={() => navigate('/main')}>
                Back to Menu
            </button>
        </div>
    );
};

export default RegisteredPatientsPage;
