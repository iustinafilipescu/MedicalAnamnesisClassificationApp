import React, {useState} from 'react';
import {useNavigate} from "react-router-dom";
import './RegisterMedicalEmployeePage.css';

const RegisterMedicalEmployeePage = () => {
    const navigate = useNavigate();

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');

    const handleRegister = async (e) => {
        e.preventDefault();

        if (!username || !password || !name) {
            alert('Please fill in all fields.');
            return;
        }

        try {
            const response = await fetch('http://localhost:8080/api/medicalemployees/post', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    username: username,
                    password: password,
                    name: name,
                }),
            });

            if (response.ok) {
                alert('Medical Employee registered successfully!');
            } else {
                alert('Failed to register Medical Employee. Please try again.');
            }
        } catch (error) {
            console.error('Error during registration:', error);
            alert('An error occurred during registration.');
        }
    };

    return (
        <div className="register-medical-employee-container">
            <div className="register-medical-employee-form-container">
                <h2 className="register-medical-employee-title">Register Medical Employee</h2>
                <form onSubmit={handleRegister} className="register-medical-employee-form">
                    <label className="full-width">
                        Username:
                        <input className="full-width" type="text" name="username" value={username}
                               onChange={(e) => setUsername(e.target.value)}/>
                    </label>
                    <label className="full-width">
                        Password:
                        <input className="full-width" type="password" name="password" value={password}
                               onChange={(e) => setPassword(e.target.value)}/>
                    </label>
                    <label className="full-width">
                        Name:
                        <input className="full-width" type="text" name="name" value={name}
                               onChange={(e) => setName(e.target.value)}/>
                    </label>
                    <button type="submit" className="register-medical-employee-submit-button">
                        Register
                    </button>
                </form>
            </div>
            <button className="back-to-menu-button" onClick={() => navigate('/main')}>Back to Menu</button>

        </div>
    );
};

export default RegisterMedicalEmployeePage;
