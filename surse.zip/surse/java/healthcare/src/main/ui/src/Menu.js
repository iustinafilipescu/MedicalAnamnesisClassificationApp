import React, {useState} from 'react';
import './Menu.css';
import {useNavigate} from 'react-router-dom';

const Menu = ({isAdmin, username}) => {
    const [showAdminOptions, setShowAdminOptions] = useState(false);
    const navigate = useNavigate();

    const toggleAdminOptions = () => {
        setShowAdminOptions(!showAdminOptions);
    };

    const handleRegisterPatientClick = () => {
        navigate('/register-patient');
    };

    const handleRegisteredPatientsClick = () => {
        navigate('/registered-patients');
    };
    const handleRegisteredEmployeesClick = () => {
        navigate('/registered-medical-employees');
    };

    const handleRegisterEmployeeClick = () => {
        navigate('/register-medical-employee');
    };

    const handleLogoutClick = () => {
        navigate('/login');
    };

    return (
        <div className="menu">
            <button className="menu-button" onClick={handleRegisterPatientClick}>
                Register a Patient
            </button>
            <button className="menu-button" onClick={handleRegisteredPatientsClick}>
                See Registered Patients
            </button>

            {isAdmin && (
                <button className="menu-button" onClick={toggleAdminOptions}>
                    Admin Options
                </button>
            )}

            {showAdminOptions && isAdmin && (
                <>
                    <button className="menu-button" onClick={handleRegisterEmployeeClick}>
                        Register Medical Employee
                    </button>
                    <button className="menu-button" onClick={handleRegisteredEmployeesClick}>See Registered Employees
                    </button>
                </>
            )}

            <button className="menu-button" onClick={handleLogoutClick}>
                Logout ({username})
            </button>
        </div>
    );
};

export default Menu;
