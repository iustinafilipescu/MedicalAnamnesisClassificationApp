import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import './Login.css';

const LoginPage = ({handleLogin}) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLoginClick = async (e) => {
        e.preventDefault();

        if (username === 'admin' && password === 'password') {
            handleLogin(username, true);
            navigate('/main');
        } else {
            try {
                const response = await authenticateUser(username, password);

                if (response.status === 200) {
                    handleLogin(username, false);
                    navigate('/main');
                } else {
                    alert('Login failed. Check username and password.');
                }
            } catch (error) {
                console.error('Error during authentication:', error);
                alert('An error occurred during authentication.');
            }
        }
    };

    const authenticateUser = async (username, password) => {
        const url = 'http://localhost:8080/api/medicalemployees/authenticate';
        const data = new URLSearchParams();
        data.append('username', username);
        data.append('password', password);

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: data,
            });

            return response;
        } catch (error) {
            console.error('Error during authentication:', error);
            throw error;
        }
    };

    return (
        <div className="login-container">
            <form className="login-form" onSubmit={handleLoginClick}>
                <h2>MedRoute AI</h2>
                <label>
                    Username:
                    <input type="text" value={username} onChange={(e) => setUsername(e.target.value)}/>
                </label>
                <label>
                    Password:
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}/>
                </label>
                <button type="submit">Login</button>
            </form>
        </div>
    );
};

export default LoginPage;
